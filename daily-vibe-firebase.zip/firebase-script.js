// Firebase config (replace with your real config)
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

const today = new Date().toISOString().split('T')[0];

db.collection("dailyVibes").doc(today).get()
  .then(doc => {
    if (doc.exists) {
      const data = doc.data();

      // Quote
      document.getElementById('quote').innerText = data.quote || "Stay inspired.";

      // Music
      if (data.song) {
        document.getElementById('song-title').innerText = `${data.song.title} by ${data.song.artist}`;
        document.getElementById('audio-player').src = data.song.url;
      } else {
        document.getElementById('song-title').innerText = "No music for today.";
      }

      // Artwork
      if (data.artworkUrl) {
        document.getElementById('artwork').src = data.artworkUrl;
      } else {
        document.getElementById('artwork').alt = "No artwork available.";
      }
    } else {
      document.getElementById('quote').innerText = "No vibe set for today.";
    }
  })
  .catch(error => {
    console.error("Error fetching daily vibe:", error);
    document.getElementById('quote').innerText = "Error loading today's vibe.";
  });
